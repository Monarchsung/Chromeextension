chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'updateStatus') {
    chrome.runtime.sendMessage({type: 'updatePopup', message: request.message});
  }
});
