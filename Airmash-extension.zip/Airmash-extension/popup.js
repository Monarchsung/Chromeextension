document.addEventListener('DOMContentLoaded', function() {
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.type === 'updatePopup') {
      document.getElementById('status').textContent = request.message;
    }
  });
});
